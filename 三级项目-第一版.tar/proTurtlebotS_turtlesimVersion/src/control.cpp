#include <vector>
#include <string>

#include <ros/ros.h>
//#include <nav_msgs/Odometry.h>
#include <turtlesim/Pose.h>
#include "pro_turtlebot_s/Location_monitor.h"
#include "geometry_msgs/Twist.h"


int main(int argc, char *argv[])
{
    setlocale(LC_ALL,"");

    ros::init(argc,argv,"control");

    ros::NodeHandle nh;

    ros::Publisher pub = nh.advertise<geometry_msgs::Twist>("/turtle1/cmd_vel",100);

    ros::Rate rate(10);

    geometry_msgs::Twist twist;

    if (argc != 2)
        {
            ROS_ERROR("输入的数量有问题：正确的格式 rosrun 包名 节点名 x(x=1,2,3,4)");
            return 1;
        }

    int command = atoi(argv[1]);

    while (ros::ok())
    {
       
        
        switch (command)
        {
        case 1:
            ROS_INFO("This is one");
            // 左转180度
            ROS_INFO("trun left 180");
            twist.angular.z = 3.14; // 设置角速度为3.14弧度/秒，使机器人以逆时针方向旋转180度
            twist.linear.x = 0.0; // 设置线速度为0，保持静止
            
            for (int i;i<4;i++)
            {
            pub.publish(twist);
            ros::Duration(2.0).sleep(); // 休眠2秒，使机器人旋转到指定角度
            ROS_INFO("turn in for");
            }

            // 直线行进
            ROS_INFO("go alone");
            twist.angular.z = 0.0; // 设置角速度为0，停止旋转
            twist.linear.x = 0.5; // 设置线速度为2.0，使机器人以2.0米/秒的速度直线行进
            //ros::Duration(5.0).sleep(); // 休眠5秒，使机器人行进一定距离

            for (int i;i<8;i++)
            {
            pub.publish(twist);
            ros::Duration(5.0).sleep(); // line
            ROS_INFO("line in for");
            }
            // 转90度
            ROS_INFO("lfft in 90");
            twist.angular.z = 1.57; // 设置角速度为1.57弧度/秒，使机器人以逆时针方向旋转90度
            twist.linear.x = 0.0; // 设置线速度为0，保持静止
            //ros::Duration(2.0).sleep(); // 休眠2秒，使机器人旋转到指定角度
            for (int i;i<1;i++)
            {
            pub.publish(twist);
            ros::Duration(5.0).sleep(); // 休眠2秒，使机器人旋转到指定角
            ROS_INFO("turn in for2");
            }
            // 直线行进
            ROS_INFO("go alone");
            twist.angular.z = 0.0; // 设置角速度为0，停止旋转
            twist.linear.x = 0.8; // 设置线速度为2.0，使机器人以2.0米/秒的速度直线行进
            //ros::Duration(5.0).sleep(); // 休眠5秒，使机器人行进一定距离

            for (int i;i<4;i++)
            {
            pub.publish(twist);
            ros::Duration(5.0).sleep(); // 休眠2秒，使机器人旋转到指定角
            ROS_INFO("line in for");
            }
            //ROS_ERROR("next!!!");
            ROS_INFO("next!!!  第一个完事!");
            return 1;
            break;

        case 2:
            /* code */
            // 左转90度
            ROS_INFO("trun left 90");
            twist.angular.z = 1.57; // 设置角速度为1.57弧度/秒，使机器人以逆时针方向旋转90度
            twist.linear.x = 0.0; // 设置线速度为0，保持静止
            
            for (int i;i<2;i++)
            {
            pub.publish(twist);
            ros::Duration(2.0).sleep(); // 休眠2秒，使机器人旋转到指定角
            ROS_INFO("turn in for");
            }
            // 以弧线的形式行进
            ROS_INFO("go alone");
            twist.angular.z = 0.01; // 设置角速度为0，停止旋转
            twist.linear.x = 0.5; // 设置线速度为2.0，使机器人以2.0米/秒的速度直线行进
            //ros::Duration(5.0).sleep(); // 休眠5秒，使机器人行进一定距离

            for (int i;i<12;i++)
            {
            pub.publish(twist);
            ros::Duration(5.0).sleep(); // line
            ROS_INFO("line in for");
            }
            //ROS_ERROR("next!!!");
            ROS_INFO("next!!! 第二个完事！");
            return 1;
            break;
        case 3:
            /* code */
            // 左转180度
            ROS_INFO("trun left 45");
            twist.angular.z = 0.3; // 设置角速度为0.785弧度/秒，使机器人以逆时针方向旋转45度
            twist.linear.x = 0.0; // 设置线速度为0，保持静止
            
            for (int i;i<4;i++)
            {
            pub.publish(twist);
            ros::Duration(2.0).sleep(); // 休眠2秒，使机器人旋转到指定角
            ROS_INFO("turn in for");
            }
            
            // 行进
            ROS_INFO("go alone");
            twist.angular.z = 0.04; // 设置角速度为0，停止旋转
            twist.linear.x = 0.5; // 设置线速度为2.0，使机器人以2.0米/秒的速度直线行进
            //ros::Duration(5.0).sleep(); // 休眠5秒，使机器人行进一定距离

            for (int i;i<12;i++)
            {
            pub.publish(twist);
            ros::Duration(5.0).sleep(); // line
            ROS_INFO("line in for");
            }
            //ROS_ERROR("next!!!");
            ROS_INFO("next!!! 第三个完事!");
            return 1;
            break;
        case 4:
            /* code */
            // 左转90度
            ROS_INFO("trun left 90");
            twist.angular.z = 1.57; // 设置角速度为1.75弧度/秒，使机器人以逆时针方向旋转90度
            twist.linear.x = 0.0; // 设置线速度为0，保持静止
            
            for (int i;i<10;i++)
            {
            pub.publish(twist);
            ros::Duration(2.0).sleep(); // 休眠2秒，使机器人旋转到指定角
            ROS_INFO("turn in for");
            }
            
            // 行进
            ROS_INFO("go alone");
            twist.angular.z = -0.02; // 设置角速度为0，停止旋转
            twist.linear.x = 0.5; // 设置线速度为2.0，使机器人以2.0米/秒的速度直线行进
            //ros::Duration(5.0).sleep(); // 休眠5秒，使机器人行进一定距离

            for (int i;i<16;i++)
            {
            pub.publish(twist);
            ros::Duration(5.0).sleep(); // line
            ROS_INFO("line in for");
            }
            //ROS_ERROR("next!!!");
            ROS_INFO("next!!! 都完事了!");
            return 1;
            break;
        /*
        case 5:
            // 左转90度
            ROS_INFO("trun left 180");
            twist.angular.z = 3.14; // 设置角速度为1.75弧度/秒，使机器人以逆时针方向旋转90度
            twist.linear.x = 0.0; // 设置线速度为0，保持静止
            
            for (int i;i<10;i++)
            {
            pub.publish(twist);
            ros::Duration(2.0).sleep(); // 休眠2秒，使机器人旋转到指定角
            ROS_INFO("turn in for");
            }
            // 行进
            ROS_INFO("go alone");
            twist.angular.z = -0.3; // 设置角速度为0，停止旋转
            twist.linear.x = 0.2; // 设置线速度为2.0，使机器人以2.0米/秒的速度直线行进
            //ros::Duration(5.0).sleep(); // 休眠5秒，使机器人行进一定距离

            for (int i;i<10;i++)
            {
            pub.publish(twist);
            ros::Duration(5.0).sleep(); // line
            ROS_INFO("line in for");
            }
            //ROS_ERROR("next!!!");
            ROS_INFO("next!!! 5 Success!");
            return 1;

            break;
        */
        
        default:
            break;
        }
        pub.publish(twist);

        rate.sleep();

        ros::spinOnce();
    }
    
    return 0;
}